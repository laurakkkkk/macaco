// Almacenamiento temporal en memoria (se reinicia con deploys)
let responses = {};

export default function handler(req, res) {
    // CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }

    // GET: obtener respuesta de Telegram
    if (req.method === 'GET') {
        const { session } = req.query;
        
        if (!session) {
            return res.status(400).json({ error: 'Session ID requerido' });
        }

        if (responses[session]) {
            const response = responses[session];
            delete responses[session]; // Eliminar después de leer
            return res.status(200).json({ 
                action: response.action,
                success: true 
            });
        }

        // No hay respuesta aún
        return res.status(200).json({ action: null });
    }

    // POST: guardar respuesta de Telegram
    if (req.method === 'POST') {
        try {
            const { session, action } = req.body;
            
            if (!session || !action) {
                return res.status(400).json({ error: 'Session y action requeridos' });
            }

            responses[session] = { 
                action,
                timestamp: Date.now()
            };

            console.log(`[Telegram Response] Session: ${session}, Action: ${action}`);

            return res.status(200).json({ 
                success: true,
                message: 'Respuesta guardada'
            });
        } catch (error) {
            console.error('Error al guardar respuesta:', error);
            return res.status(500).json({ error: 'Error interno' });
        }
    }

    return res.status(405).json({ error: 'Método no permitido' });
}
